// index.js
const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

// initial in-memory data
let todos = [
  { id: 1, task: "Learn Node", done: false }
];

// 1) GET /todos → List all tasks
app.get('/todos', (req, res) => {
  res.json(todos);
});

// 2) POST /todos → Add a new task
// body: { "task": "Practice Express" }
app.post('/todos', (req, res) => {
  const { task } = req.body;
  if (!task || typeof task !== 'string') {
    return res.status(400).json({ message: "Invalid task in body" });
  }
  const newId = todos.length ? Math.max(...todos.map(t => t.id)) + 1 : 1;
  const newTodo = { id: newId, task: task.trim(), done: false };
  todos.push(newTodo);
  res.status(201).json({ message: "Task added", todo: newTodo });
});

// 3) PATCH /todos/:id → Update done to true
app.patch('/todos/:id', (req, res) => {
  const id = Number(req.params.id);
  const todo = todos.find(t => t.id === id);
  if (!todo) {
    return res.status(404).json({ message: "Task not found" });
  }
  todo.done = true;
  res.json({ message: "Task updated", todo });
});

// Optional: DELETE /todos/:id (handy for testing)
app.delete('/todos/:id', (req, res) => {
  const id = Number(req.params.id);
  const idx = todos.findIndex(t => t.id === id);
  if (idx === -1) return res.status(404).json({ message: "Task not found" });
  const removed = todos.splice(idx, 1)[0];
  res.json({ message: "Task removed", todo: removed });
});

app.listen(port, () => {
  console.log(`To-Do API running on http://localhost:${port}`);
});
