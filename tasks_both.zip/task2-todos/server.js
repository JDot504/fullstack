const express = require("express");
const app = express();
app.use(express.json());
let todos = [{ id: 1, task: "Learn Node", done: false }];
let nextId = 2;
app.get("/todos", (req, res) => {
  res.json(todos);
});
app.post("/todos", (req, res) => {
  const { task } = req.body;
  if (!task) return res.status(400).json({ error: "Task is required" });
  const todo = { id: nextId++, task, done: false };
  todos.push(todo);
  res.status(201).json(todo);
});
app.patch("/todos/:id", (req, res) => {
  const id = Number(req.params.id);
  const todo = todos.find(t => t.id === id);
  if (!todo) return res.status(404).json({ error: "Not found" });
  todo.done = true;
  res.json({ message: "Updated", todo });
});
const PORT = 3002;
app.listen(PORT, () => console.log(`Task 2 server running on port ${PORT}`));
