This ZIP contains two small Express projects ready to run.

1) task1-students
   - Port: 3001
   - Routes:
     GET  /students
     POST /students   body: { "name": "...", "marks": number }
     GET  /students/:id

2) task2-todos
   - Port: 3002
   - Routes:
     GET  /todos
     POST /todos      body: { "task": "..." }
     PATCH /todos/:id

How to run (for each project):
  cd <project-folder>
  npm install
  npm start

Note: The uploaded PDF file path included below as 'original-pdf-path.txt'.
