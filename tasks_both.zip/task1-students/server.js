const express = require('express');
const app = express();
app.use(express.json());
let students = [{ id: 1, name: "Amit", marks: 85 }];
let nextId = 2;
app.get('/students', (req, res) => {
  res.json(students);
});
app.post('/students', (req, res) => {
  const { name, marks } = req.body;
  if (!name || typeof marks !== 'number') return res.status(400).json({ error: "Invalid body" });
  const student = { id: nextId++, name, marks };
  students.push(student);
  res.status(201).json(student);
});
app.get('/students/:id', (req, res) => {
  const id = Number(req.params.id);
  const s = students.find(x => x.id === id);
  if (!s) return res.status(404).json({ error: "Not found" });
  res.json(s);
});
const PORT = 3001;
app.listen(PORT, () => console.log(`Task1 running on ${PORT}`));
